# Formulario de Firma Digital

Aplicación web para capturar firmas digitales y almacenarlas en Google Drive.

## Configuración

1. Clonar el repositorio
2. Instalar dependencias: `npm install`
3. Ejecutar en desarrollo: `npm run dev`
4. Construir para producción: `npm run build`

## Despliegue

La aplicación está configurada para desplegarse en Vercel automáticamente.

## Tecnologías

- Vite
- Google Drive API
- Airtable API
